#!/bin/sh

perl ./check_aixerrpt.pl
